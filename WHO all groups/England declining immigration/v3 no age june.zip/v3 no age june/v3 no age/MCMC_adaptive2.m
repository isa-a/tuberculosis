% Adaptive MCMC, using Haario et al:
% https://link.springer.com/article/10.1007/s11222-008-9110-y
% and
% http://probability.ca/jeff/ftpdir/adaptex.pdf

% F:          Function giving log-posterior density for a parameter set x
% x0:         Initial value of parameter set x
% n:          Number of iterations
% cov0:       Initial covariance matrix
% fac:        Scaling factor for covariance matrix. Set fac = 1 for default
% displ:      Structure with display options. Set displ = true to show progress

function [xsto, outsto, history, accept_rate] = MCMC_adaptive(F, x0, n, sigma, cov0, displ)

d = length(x0); b = 0.05; sd = sigma*2.4^2/d; sd = 1;

% Checks on the initial covariance matrix
if isempty(cov0)
    cov0 = 1e-2*eye(d); 
end

% Initiate the output matrices
xsto = zeros(d,n); outsto = zeros(1,n);
history = zeros(d+1,n);                                                    % Rows: 1:d Proposed values 4. Accept or reject

xsto(:,1) = x0(:); xbar = xsto;
FX = F(x0); outsto(1) = FX;
acc = 0;

if displ; figure; end

% --- Start the MCMC loop -------------------------------------------------
for t = 2:n
    
    X = xsto(:,t-1);
    
    % --- Make a proposal from the distribution
    Y0 = mvnrnd(X,0.1^2*cov0*sigma/d);
    if t < 101
        Y = max(Y0,0); 
    else
        ind0 = t-100; ind1 = t-1;
        covmat = cov(xsto(:,ind0:ind1)');
        % Need to modify this bit so it goes recursively - faster
        %covmat(abs(covmat)<1e-10) = 1e4*covmat(abs(covmat)<1e-10);
        covmat = (covmat+covmat.')/2;
        
        % Precaution to make sure values don't get negative
        try
            Y = max((1-b)*mvnrnd(X,sd*covmat) + b*Y0,0);
        catch
            if exist('covmat_old')
                covmat = covmat_old; 
            else
                covmat = cov0;
            end
            Y = max((1-b)*mvnrnd(X,sd*covmat) + b*Y0,0);
        end
        covmat_old = covmat;
    end
    history(1:d,t) = Y;
    
    % --- Decide whether to accept or not
    FY = F(Y);
    if (rand < exp(FY-FX)) && (abs(FY) < Inf)
        % Accept
        xsel = Y(:);
        FX = FY;
        acc = acc+1;
        history(end,t) = 1;
    else
        % Reject
        xsel = xsto(:,t-1);
    end
    xsto(:,t) = xsel;
    outsto(t) = FX;
    xbar(:,t) = (xbar(:,t-1)*(t-1) + xsel)/t;
    
    % Display options
    if displ && (mod(t,round(n/25))==0); fprintf('%0.5g ', t/n*25); end
    if displ && (mod(t,200)==0)
        plot(xsto(:,1:t-1)'); xlim([0 n]); drawnow;
    end
end

accept_rate = acc/n;
xsto = xsto';
history = history';